/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mp3_hint1;

import domain.Product;
import domain.ProductMessage;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

    
    
/**
 *
 * @author kimont
 */
public class MP3_Hint1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        List<Product> productList = new ArrayList();
        productList.add(new Product(980001,19985678,"SW",1095.00f,800000,8.25f,"TRUE","Identity Server"));
        productList.add(new Product(980005,19986982,"SW",11500.99f,500,55.25f,"TRUE","Accounting Application"));
        productList.add(new Product(980025,19974892,"HW",2095.99f,3000,15.75f,"TRUE","1Ghz Sun Blade Computer"));

        // Create and display a random product...
        Product randomProduct = generateRandomProduct(productList);        
        //System.out.println(randomProduct);
        
        // Create and display a productMessage object with random regionID and random product;
        ProductMessage productMessage = createProductMessage(randomProduct);       
        System.out.println(productMessage);
    }

    private static Product generateRandomProduct(List<Product> productList) {
        Product randomProduct = null;
        Random rnd = new Random();
        int rndIndex = rnd.nextInt(3);
        return randomProduct = productList.get(rndIndex);
    }

    private static ProductMessage createProductMessage(Product randomProduct) {
        ProductMessage productMessage = null;
        char [] regionIds = {'N','S','E','W'};
        Random rnd = new Random();
        int rndIndex = rnd.nextInt(4);
        return productMessage = new ProductMessage(randomProduct,new Date(),regionIds[rndIndex]);
    }        
}
