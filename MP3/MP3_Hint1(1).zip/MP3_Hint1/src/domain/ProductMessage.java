/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.util.Date;

/**
 *
 * @author kimont
 */
public class ProductMessage {
    
    private Product product;
    private Date timestamp;
    private char regionID;

    public ProductMessage(Product product, Date timestamp, char regionID) {
        this.product = product;
        this.timestamp = timestamp;
        this.regionID = regionID;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public char getRegionID() {
        return regionID;
    }

    public void setRegionID(char regionID) {
        this.regionID = regionID;
    }

    @Override
    public String toString() {
        return "ProductMessage{" + "product=" + product + ", timestamp=" + timestamp + ", regionID=" + regionID + '}';
    }

}
