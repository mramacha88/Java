package domain;

//file: NamedConsumer.java

import java.util.ArrayList;
import java.util.List;

public class NamedConsumer implements Runnable {

    private Producer producer;
    private String name;
    private long sleepInterval;
    private List<Message> msgList;

    public NamedConsumer(String name, Producer producer, long sleepInterval) {
        this.producer = producer;
        this.name = name;
        this.sleepInterval = sleepInterval;
        msgList = new ArrayList();
    }

    public void run() {
        while (true) {
            Message message = producer.getMessage(name);
            if (message != null) {
                msgList.add(message);
                System.out.println("Consumer: " + name + " got message: " + message + " of " + producer.getListSize() + " messages...");
            }
            try {
                Thread.sleep(sleepInterval);
            } catch (InterruptedException e) {
            }
        }
    }

    @Override
    public String toString() {
        return "NamedConsumer{" + "producer=" + producer + ", name=" + name + ", sleepInterval=" + sleepInterval + ", msgList=" + msgList + '}';
    }
    
    
}
