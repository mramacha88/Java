/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

/**
 *
 * @author kimont
 */
public class Message {
    private String consumerName;
    private String timedatestamp;

    public Message() {
    }

    public Message(String consumerName, String timedatestamp) {
        this.consumerName = consumerName;
        this.timedatestamp = timedatestamp;
    }

    public String getConsumerName() {
        return consumerName;
    }

    public void setConsumerName(String consumerName) {
        this.consumerName = consumerName;
    }

    public String getTimedatestamp() {
        return timedatestamp;
    }

    public void setTimedatestamp(String timedatestamp) {
        this.timedatestamp = timedatestamp;
    }

    @Override
    public String toString() {
        return "Message{" + "consumerName=" + consumerName + ", timedatestamp=" + timedatestamp + '}';
    }

}
