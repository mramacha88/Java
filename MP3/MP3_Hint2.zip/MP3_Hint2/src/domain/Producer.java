package domain;

import java.util.*;

public class Producer implements Runnable {

    static final int MAXQUEUE = 5;
    private List<Message> messages = new ArrayList();  
    private List<String> consumers = null; 

    public Producer(List<String> consumers) {
        this.consumers = consumers;
    }

    public void run() {
        while (true) {
            putMessage();
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
            }
        }
    }

    private synchronized void putMessage() {
        while (messages.size() >= MAXQUEUE) {
            try {
                wait();
            } catch (InterruptedException e) {
            }
        }
        // Get random consumer and pass into message object...
        Random rnd = new Random();
        int index = rnd.nextInt(3);
        
        messages.add(new Message(consumers.get(index),new java.util.Date().toString()));
        System.out.println("Producer: Queue has " + messages.size() + " messages...");
        notify();
    }

    // called by Consumer
    public synchronized Message getMessage(String consumerName) {
        while (messages.size() == 0) {
            try {
                notify();
                wait();
            } catch (InterruptedException e) {
            }
        }
        Message message = messages.get(0);
        
        if (message.getConsumerName().equals(consumerName)) {
            message = (Message) messages.remove(0);
        } else {
            message = null;
        }
        
        notify();
        return message;
    }

    public int getListSize() {
        return messages.size();
    }
}

