/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package consumerproducer;

import domain.NamedConsumer;
import domain.Producer;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author kimont
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        List<String> consumers = new ArrayList();
        consumers.add("One");
        consumers.add("Two");
        consumers.add("Three");
        
        Producer producer = new Producer(consumers);
        new Thread(producer).start();

        NamedConsumer consumer1 = new NamedConsumer(consumers.get(0), producer, 5000L);
        Thread c1 = new Thread(consumer1);
        c1.setDaemon(true);
        c1.start();
        NamedConsumer consumer2 = new NamedConsumer(consumers.get(1), producer, 6000L);
        Thread c2 = new Thread(consumer2);
        c2.setDaemon(true);
        c2.start();
        NamedConsumer consumer3 = new NamedConsumer(consumers.get(2), producer, 7000L);
        Thread c3 = new Thread(consumer3);
        c3.setDaemon(true);
        c3.start();

        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Press a key to exit...");
            in.read();
            System.out.println("NamedConsumer One data: " + consumer1 + "\n");
            System.out.println("NamedConsumer Two data: " + consumer2 + "\n");
            System.out.println("NamedConsumer Three data: " + consumer3 + "\n");
            System.out.println("Exiting....");
            in.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } finally {
            System.exit(0);
        }
    }
}
