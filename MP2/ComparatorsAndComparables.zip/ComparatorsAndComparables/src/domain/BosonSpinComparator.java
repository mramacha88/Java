/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.util.Comparator;

/**
 *
 * @author kimont
 */
public class BosonSpinComparator implements Comparator {
    
    public BosonSpinComparator() { } 

    @Override
    public int compare(Object o1, Object o2) {
        
        // Since we comparing bosons, downcast 01 and o2 objects...
        Boson b1 = (Boson)o1;
        Boson b2 = (Boson)o2;
         
        // Now, compare spins...
        if (b1.getSpin() > b2.getSpin()) {
            return 1;
        } else if (b1.getSpin() < b2.getSpin()) {
            return -1;
        } else {
            return 0;
        }
    } 
}
