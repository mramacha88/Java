/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

/**
 *
 * @author kimont
 */
public class Boson implements Comparable {
    
    // Instance Fields...
    private String name;
    private int spin;
    private double mass;
    
    // Constructors...

    public Boson(String name, int spin, double mass) {
        this.name = name;
        this.spin = spin;
        this.mass = mass;
    }
    
    // Setters and Getters...

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSpin() {
        return spin;
    }

    public void setSpin(int spin) {
        this.spin = spin;
    }

    public double getMass() {
        return mass;
    }

    public void setMass(double mass) {
        this.mass = mass;
    }
    
    // Helper Methods...

    @Override
    public String toString() {
        return "Boson{" + "name=" + name + ", spin=" + spin + ", mass=" + mass + '}';
    }

    @Override
    public int compareTo(Object o) {
        Boson b = (Boson)o;
        if (this.getMass() > b.getMass()) {
            return 1;
        } else if (this.getMass() <= b.getMass()) {
            return -1;
        } else {
            return 0;
        }
    }
}
