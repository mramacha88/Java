/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package comparatorsandcomparables;

import domain.Boson;
import domain.BosonSpinComparator;
import java.util.Comparator;

/**
 *
 * @author kimont
 */
public class ComparatorsAndComparables {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Create boson objects...
        Boson photon = new Boson("Photon", 1, 0);
        Boson higgs = new Boson("Higgs", 0, 125.3);
        
        // Compare boson spins with Comparator class...
        Comparator spinComparator = new BosonSpinComparator();
        int spinComparison = spinComparator.compare(photon, higgs); 
        displaySpinComparison(spinComparison);
            
        // Compare boson masses with Comparable interface implementation...
        int massComparison = photon.compareTo(higgs);
        // or...
        // massComparaison = higgs.compareTo(photon);
        displayMassComparison(massComparison);
    }

    private static void displaySpinComparison(int spinComparison) {
        if (spinComparison > 0) {
            System.out.println("Photon's spin is greater than Higgs.");
        } else if (spinComparison < 0) {
            System.out.println("Photon's spin is less than the Higgs.");
        } else {
            System.out.println("Spin is the same.");
        }   
    }

    private static void displayMassComparison(int massComparison) {
        if (massComparison > 0) {
            System.out.println("Photon's mass is greater than Higgs.");
        } else if (massComparison < 0) {
            System.out.println("Photon's mass is less than the Higgs.");
        } else {
            System.out.println("Masses are equal.");
        } 
    }
}
