/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package midtermexam_domain;

/**
 *
 * @author Meghashree M Ramachandra
 */
interface Audible {
    public String animalTalk(); // abstract methods only inside interfaces...
}
