/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package midtermexam_domain;

/**
 *
 * @author Meghashree M Ramachandra
 */
public interface Relatable {
    boolean isLouder(Object obj);   
}
