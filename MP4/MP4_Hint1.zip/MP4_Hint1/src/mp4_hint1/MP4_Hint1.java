/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mp4_hint1;

import utilties.UtilityFunctions;
import java.util.Scanner;


/**
 *
 * @author kimont
 */
public class MP4_Hint1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        while (true) {
            UtilityFunctions.displayMenu();
            UtilityFunctions.getUserSelection(new Scanner(System.in));
        }
    }
}
