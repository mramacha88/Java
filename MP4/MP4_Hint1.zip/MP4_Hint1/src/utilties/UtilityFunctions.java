/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utilties;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import mp4_hint1.MP4_Hint1;

/**
 *
 * @author kimont
 */
public class UtilityFunctions {
    
    public static void a() {
        System.out.println("In a().");
    }
    
    public static void b() {
        System.out.println("In b().");
    }
    
    public static void c() {
        System.out.println("In c().");
    }
    
     public static void displayMenu() {
        // Create recurring command line menu...
        // Selected option will invoke an assitive method outside of this driver class...
        System.out.println("Please enter choice from the following options: ");
        System.out.println(
                "a - execute the a function.\n"
                + "b - execute the b function.\n"
                + "c - execute the c function.\n"
                + "q - quit the application.\n");
    }

    public static void getUserSelection(Scanner s) {
        if (s.hasNext()) {
            displayMenu();
            switch (s.next()) {
                case "a":
                    System.out.println("Executing function a()...");
                    UtilityFunctions.a();
                    break;
                case "b":
                    System.out.println("Executing function b()...");
                    UtilityFunctions.b();
                    break;
                case "c":
                    System.out.println("Executing function c()...");
                    UtilityFunctions.c();
                    break;
                case "q":
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
            }
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ex) {
                Logger.getLogger(MP4_Hint1.class
                        .getName()).log(Level.SEVERE, null, ex);
            }
            s.reset();
        }
    }
    
}
