/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mp4_hint2;

import domain.Record;
import java.util.List;
import utilities.JDBCUtilities;

/**
 *
 * @author kimont
 */
public class MP4_Hint2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Invoke all CRUD operations on table...
        // Locate the following method calls inside of each case statement in project MP4_Hint1!!!
        List<Record> records;
        
        boolean createResult = JDBCUtilities.createRecord();
        Record record = JDBCUtilities.retrieveRecord();
        records = JDBCUtilities.retrieveAllRecords();
        for (Record r : records) {
            System.out.println(r);
        }
        boolean updateResult = JDBCUtilities.updateRecord();
        boolean deleteResult = JDBCUtilities.deleteRecord();
    }
}
