/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utilities;

import domain.Record;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author kimont
 */
public class JDBCUtilities {
    
    public static boolean createRecord() {
        return true;
    }
    
    public static Record retrieveRecord() {
        
        return null;
    }
    
    public static List retrieveAllRecords() {
        Connection conn = getConnection();
        List<Record> recList = null;
        try {
            recList = new ArrayList();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Customers;");
            while (rs.next()) {
                int customerNumber = rs.getInt("customerNumber");
                String customerName = rs.getString("customerName");
                String contactFirstName = rs.getString("contactFirstName");
                String contactLastName = rs.getString("contactLastName");
                String phone = rs.getString("phone");
                String addressLine1 = rs.getString("addressLine1");
                String addressLine2 = rs.getString("addressLine2");
                String city = rs.getString("city");
                String state = rs.getString("state");
                String postalCode = rs.getString("postalCode");
                String country = rs.getString("country");
                int salesRepEmployeeNumber = rs.getInt("salesRepEmployeeNumber");
                double creditLimit = rs.getDouble("creditLimit");
                Record rec = new Record(customerNumber,customerName,contactFirstName,contactLastName,
                        phone,addressLine1,addressLine2,city,state,postalCode,country,
                        salesRepEmployeeNumber,creditLimit);
                recList.add(rec);
            }
        } catch (SQLException ex) {
            Logger.getLogger(JDBCUtilities.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(conn != null) conn.close();
            } catch (SQLException ex) {
                Logger.getLogger(JDBCUtilities.class.getName()).log(Level.SEVERE, null, ex);
            }
        }    
        return recList;
    }
    
    public static boolean updateRecord() {
        return true;
    }
       
    public static boolean deleteRecord() {
        return true;
    }
    
     private static Connection getConnection() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/itm411DB","root","admin");
        } catch (SQLException ex) {
            Logger.getLogger(JDBCUtilities.class.getName()).log(Level.SEVERE, null, ex);
        }
        return conn;
    }
}
