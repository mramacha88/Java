/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mp4_hint2;

import domain.CustomerRecord;
import java.util.List;
import utilities.JDBCUtilities;

/**
 *
 * @author kimont
 */
public class MP4_Hint2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Invoke all CRUD operations on table...
        // Locate the following method calls inside of each case statement in project MP4_Hint1!!!
        List<CustomerRecord> records;
        
        boolean createResult = JDBCUtilities.createRecord();
        
        CustomerRecord record = JDBCUtilities.retrieveRecord();
        System.out.println(record + "\n");
        
        records = JDBCUtilities.retrieveAllRecords();
        for (CustomerRecord r : records) {
            System.out.println(r);
        }
        System.out.println();
        
        if (JDBCUtilities.updateRecord()) {
            System.out.println("Record was updated...");
        } else {
            System.out.println("Record was not updated...");
        }
        
        if (JDBCUtilities.deleteRecord()) {
            System.out.println("Record was deleted...");
        } else {
            System.out.println("Record was not deleted...");
        }
    }
}
